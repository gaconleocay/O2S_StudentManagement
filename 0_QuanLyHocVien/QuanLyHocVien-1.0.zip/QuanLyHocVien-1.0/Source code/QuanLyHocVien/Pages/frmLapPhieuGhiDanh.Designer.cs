﻿namespace QuanLyHocVien.Pages
{
    partial class frmLapPhieuGhiDanh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gridDSHV = new System.Windows.Forms.DataGridView();
            this.clmMaHV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmTenHV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmNgaySinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmGioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rdTenHV = new System.Windows.Forms.RadioButton();
            this.rdMaHV = new System.Windows.Forms.RadioButton();
            this.btnDatLai = new System.Windows.Forms.Button();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.txtTenHV = new System.Windows.Forms.TextBox();
            this.txtMaHV = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnHienTatCa = new System.Windows.Forms.Button();
            this.lblTongCongHV = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnDatLaiPhieu = new System.Windows.Forms.Button();
            this.btnInBienLai = new System.Windows.Forms.Button();
            this.btnLuuPhieu = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.numConNo = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.numDaDong = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numHocPhi = new System.Windows.Forms.NumericUpDown();
            this.dateNgayGhiDanh = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.cboKhoaHoc = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMaPhieu = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.gridPhieuGhiDanh = new System.Windows.Forms.DataGridView();
            this.clmMaPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmMaHV_DS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmNgayGhiDanh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDaDong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmConNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTongCongPhieu = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDSHV)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numConNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaDong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHocPhi)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPhieuGhiDanh)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1066, 24);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(18, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "LẬP PHIẾU GHI DANH";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.LightGray;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = global::QuanLyHocVien.Properties.Resources.icon_Close_9dp;
            this.btnClose.Location = new System.Drawing.Point(1026, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(28, 19);
            this.btnClose.TabIndex = 0;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.gridDSHV);
            this.panel2.Controls.Add(this.rdTenHV);
            this.panel2.Controls.Add(this.rdMaHV);
            this.panel2.Controls.Add(this.btnDatLai);
            this.panel2.Controls.Add(this.btnTimKiem);
            this.panel2.Controls.Add(this.txtTenHV);
            this.panel2.Controls.Add(this.txtMaHV);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.btnHienTatCa);
            this.panel2.Controls.Add(this.lblTongCongHV);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(374, 474);
            this.panel2.TabIndex = 2;
            // 
            // gridDSHV
            // 
            this.gridDSHV.AllowUserToAddRows = false;
            this.gridDSHV.AllowUserToResizeRows = false;
            this.gridDSHV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridDSHV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridDSHV.BackgroundColor = System.Drawing.Color.White;
            this.gridDSHV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gridDSHV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDSHV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmMaHV,
            this.clmTenHV,
            this.clmNgaySinh,
            this.clmGioiTinh});
            this.gridDSHV.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gridDSHV.Location = new System.Drawing.Point(12, 182);
            this.gridDSHV.MultiSelect = false;
            this.gridDSHV.Name = "gridDSHV";
            this.gridDSHV.RowHeadersVisible = false;
            this.gridDSHV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDSHV.Size = new System.Drawing.Size(345, 231);
            this.gridDSHV.TabIndex = 2;
            this.gridDSHV.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.gridDSHV_RowsAdded);
            this.gridDSHV.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.gridDSHV_RowsRemoved);
            this.gridDSHV.Click += new System.EventHandler(this.gridDSHV_Click);
            // 
            // clmMaHV
            // 
            this.clmMaHV.DataPropertyName = "MaHV";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Blue;
            this.clmMaHV.DefaultCellStyle = dataGridViewCellStyle1;
            this.clmMaHV.HeaderText = "Mã";
            this.clmMaHV.Name = "clmMaHV";
            // 
            // clmTenHV
            // 
            this.clmTenHV.DataPropertyName = "TenHV";
            this.clmTenHV.HeaderText = "Họ tên";
            this.clmTenHV.Name = "clmTenHV";
            // 
            // clmNgaySinh
            // 
            this.clmNgaySinh.DataPropertyName = "NgaySinh";
            this.clmNgaySinh.HeaderText = "Ngày sinh";
            this.clmNgaySinh.Name = "clmNgaySinh";
            // 
            // clmGioiTinh
            // 
            this.clmGioiTinh.DataPropertyName = "GioiTinhHV";
            this.clmGioiTinh.HeaderText = "Giới tính";
            this.clmGioiTinh.Name = "clmGioiTinh";
            // 
            // rdTenHV
            // 
            this.rdTenHV.AutoSize = true;
            this.rdTenHV.Location = new System.Drawing.Point(21, 76);
            this.rdTenHV.Name = "rdTenHV";
            this.rdTenHV.Size = new System.Drawing.Size(79, 19);
            this.rdTenHV.TabIndex = 40;
            this.rdTenHV.TabStop = true;
            this.rdTenHV.Text = "Họ và tên:";
            this.rdTenHV.UseVisualStyleBackColor = true;
            this.rdTenHV.CheckedChanged += new System.EventHandler(this.rdTenHV_CheckedChanged);
            // 
            // rdMaHV
            // 
            this.rdMaHV.AutoSize = true;
            this.rdMaHV.Checked = true;
            this.rdMaHV.Location = new System.Drawing.Point(21, 36);
            this.rdMaHV.Name = "rdMaHV";
            this.rdMaHV.Size = new System.Drawing.Size(90, 19);
            this.rdMaHV.TabIndex = 39;
            this.rdMaHV.TabStop = true;
            this.rdMaHV.Text = "Mã học viên";
            this.rdMaHV.UseVisualStyleBackColor = true;
            this.rdMaHV.CheckedChanged += new System.EventHandler(this.rdMaHV_CheckedChanged);
            // 
            // btnDatLai
            // 
            this.btnDatLai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDatLai.BackColor = System.Drawing.Color.Silver;
            this.btnDatLai.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnDatLai.FlatAppearance.BorderSize = 0;
            this.btnDatLai.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnDatLai.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDatLai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDatLai.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDatLai.Image = global::QuanLyHocVien.Properties.Resources.refresh_16x16;
            this.btnDatLai.Location = new System.Drawing.Point(275, 106);
            this.btnDatLai.Name = "btnDatLai";
            this.btnDatLai.Size = new System.Drawing.Size(82, 29);
            this.btnDatLai.TabIndex = 38;
            this.btnDatLai.Text = "Đặt lại";
            this.btnDatLai.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDatLai.UseVisualStyleBackColor = false;
            this.btnDatLai.Click += new System.EventHandler(this.btnDatLai_Click);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimKiem.BackColor = System.Drawing.Color.Silver;
            this.btnTimKiem.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnTimKiem.FlatAppearance.BorderSize = 0;
            this.btnTimKiem.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnTimKiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimKiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTimKiem.Image = global::QuanLyHocVien.Properties.Resources.zoom_16x16;
            this.btnTimKiem.Location = new System.Drawing.Point(170, 106);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(99, 29);
            this.btnTimKiem.TabIndex = 37;
            this.btnTimKiem.Text = "Tìm kiếm";
            this.btnTimKiem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimKiem.UseVisualStyleBackColor = false;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // txtTenHV
            // 
            this.txtTenHV.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenHV.Enabled = false;
            this.txtTenHV.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTenHV.Location = new System.Drawing.Point(118, 75);
            this.txtTenHV.Name = "txtTenHV";
            this.txtTenHV.Size = new System.Drawing.Size(239, 23);
            this.txtTenHV.TabIndex = 36;
            // 
            // txtMaHV
            // 
            this.txtMaHV.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaHV.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaHV.Location = new System.Drawing.Point(118, 35);
            this.txtMaHV.Name = "txtMaHV";
            this.txtMaHV.Size = new System.Drawing.Size(239, 23);
            this.txtMaHV.TabIndex = 34;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(135, 15);
            this.label15.TabIndex = 32;
            this.label15.Text = "Tìm kiếm học viên theo:";
            // 
            // btnHienTatCa
            // 
            this.btnHienTatCa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHienTatCa.BackColor = System.Drawing.Color.Silver;
            this.btnHienTatCa.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnHienTatCa.FlatAppearance.BorderSize = 0;
            this.btnHienTatCa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnHienTatCa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnHienTatCa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHienTatCa.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnHienTatCa.Image = global::QuanLyHocVien.Properties.Resources.show_16x16;
            this.btnHienTatCa.Location = new System.Drawing.Point(244, 419);
            this.btnHienTatCa.Name = "btnHienTatCa";
            this.btnHienTatCa.Size = new System.Drawing.Size(113, 29);
            this.btnHienTatCa.TabIndex = 31;
            this.btnHienTatCa.Text = "Hiện tất cả";
            this.btnHienTatCa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHienTatCa.UseVisualStyleBackColor = false;
            this.btnHienTatCa.Click += new System.EventHandler(this.btnHienTatCa_Click);
            // 
            // lblTongCongHV
            // 
            this.lblTongCongHV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTongCongHV.AutoSize = true;
            this.lblTongCongHV.Location = new System.Drawing.Point(12, 450);
            this.lblTongCongHV.Name = "lblTongCongHV";
            this.lblTongCongHV.Size = new System.Drawing.Size(154, 15);
            this.lblTongCongHV.TabIndex = 4;
            this.lblTongCongHV.Text = "Tổng cộng: <num> kết quả";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Kết quả tìm kiếm học viên";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(374, 24);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 474);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnDatLaiPhieu);
            this.panel4.Controls.Add(this.btnInBienLai);
            this.panel4.Controls.Add(this.btnLuuPhieu);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.numConNo);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.numDaDong);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.numHocPhi);
            this.panel4.Controls.Add(this.dateNgayGhiDanh);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.cboKhoaHoc);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txtMaPhieu);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(379, 24);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(406, 474);
            this.panel4.TabIndex = 4;
            // 
            // btnDatLaiPhieu
            // 
            this.btnDatLaiPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDatLaiPhieu.BackColor = System.Drawing.Color.Silver;
            this.btnDatLaiPhieu.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnDatLaiPhieu.FlatAppearance.BorderSize = 0;
            this.btnDatLaiPhieu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnDatLaiPhieu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDatLaiPhieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDatLaiPhieu.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDatLaiPhieu.Image = global::QuanLyHocVien.Properties.Resources.refresh2_16x16;
            this.btnDatLaiPhieu.Location = new System.Drawing.Point(304, 315);
            this.btnDatLaiPhieu.Name = "btnDatLaiPhieu";
            this.btnDatLaiPhieu.Size = new System.Drawing.Size(83, 34);
            this.btnDatLaiPhieu.TabIndex = 31;
            this.btnDatLaiPhieu.Text = "Đặt lại";
            this.btnDatLaiPhieu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDatLaiPhieu.UseVisualStyleBackColor = false;
            this.btnDatLaiPhieu.Click += new System.EventHandler(this.btnDatLaiPhieu_Click);
            // 
            // btnInBienLai
            // 
            this.btnInBienLai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInBienLai.BackColor = System.Drawing.Color.Silver;
            this.btnInBienLai.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnInBienLai.FlatAppearance.BorderSize = 0;
            this.btnInBienLai.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnInBienLai.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnInBienLai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInBienLai.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnInBienLai.Image = global::QuanLyHocVien.Properties.Resources.print_16x16;
            this.btnInBienLai.Location = new System.Drawing.Point(205, 315);
            this.btnInBienLai.Name = "btnInBienLai";
            this.btnInBienLai.Size = new System.Drawing.Size(93, 34);
            this.btnInBienLai.TabIndex = 30;
            this.btnInBienLai.Text = "In biên lai";
            this.btnInBienLai.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnInBienLai.UseVisualStyleBackColor = false;
            this.btnInBienLai.Click += new System.EventHandler(this.btnInBienLai_Click);
            // 
            // btnLuuPhieu
            // 
            this.btnLuuPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLuuPhieu.BackColor = System.Drawing.Color.Silver;
            this.btnLuuPhieu.FlatAppearance.BorderSize = 0;
            this.btnLuuPhieu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnLuuPhieu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnLuuPhieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuuPhieu.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuuPhieu.Image = global::QuanLyHocVien.Properties.Resources.save_16x16;
            this.btnLuuPhieu.Location = new System.Drawing.Point(98, 315);
            this.btnLuuPhieu.Name = "btnLuuPhieu";
            this.btnLuuPhieu.Size = new System.Drawing.Size(101, 34);
            this.btnLuuPhieu.TabIndex = 29;
            this.btnLuuPhieu.Text = "Lưu phiếu";
            this.btnLuuPhieu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLuuPhieu.UseVisualStyleBackColor = false;
            this.btnLuuPhieu.Click += new System.EventHandler(this.btnLuuPhieu_Click);
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(369, 257);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 21);
            this.label11.TabIndex = 28;
            this.label11.Text = "đ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 257);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 15);
            this.label12.TabIndex = 27;
            this.label12.Text = "Còn nợ:";
            // 
            // numConNo
            // 
            this.numConNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numConNo.BackColor = System.Drawing.Color.White;
            this.numConNo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.numConNo.ForeColor = System.Drawing.Color.Red;
            this.numConNo.Location = new System.Drawing.Point(111, 255);
            this.numConNo.Maximum = new decimal(new int[] {
            1661992959,
            1808227885,
            5,
            0});
            this.numConNo.Name = "numConNo";
            this.numConNo.ReadOnly = true;
            this.numConNo.Size = new System.Drawing.Size(258, 29);
            this.numConNo.TabIndex = 26;
            this.numConNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(369, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 21);
            this.label8.TabIndex = 25;
            this.label8.Text = "đ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 214);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 24;
            this.label10.Text = "Đã đóng:";
            // 
            // numDaDong
            // 
            this.numDaDong.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numDaDong.BackColor = System.Drawing.Color.White;
            this.numDaDong.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.numDaDong.ForeColor = System.Drawing.Color.Blue;
            this.numDaDong.Location = new System.Drawing.Point(111, 206);
            this.numDaDong.Maximum = new decimal(new int[] {
            1661992959,
            1808227885,
            5,
            0});
            this.numDaDong.Name = "numDaDong";
            this.numDaDong.Size = new System.Drawing.Size(258, 29);
            this.numDaDong.TabIndex = 23;
            this.numDaDong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numDaDong.ValueChanged += new System.EventHandler(this.numDaDong_ValueChanged);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(369, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 21);
            this.label7.TabIndex = 22;
            this.label7.Text = "đ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 21;
            this.label6.Text = "Học phí:";
            // 
            // numHocPhi
            // 
            this.numHocPhi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numHocPhi.BackColor = System.Drawing.Color.White;
            this.numHocPhi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.numHocPhi.ForeColor = System.Drawing.Color.Blue;
            this.numHocPhi.Location = new System.Drawing.Point(111, 158);
            this.numHocPhi.Maximum = new decimal(new int[] {
            1661992959,
            1808227885,
            5,
            0});
            this.numHocPhi.Name = "numHocPhi";
            this.numHocPhi.ReadOnly = true;
            this.numHocPhi.Size = new System.Drawing.Size(258, 29);
            this.numHocPhi.TabIndex = 20;
            this.numHocPhi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dateNgayGhiDanh
            // 
            this.dateNgayGhiDanh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dateNgayGhiDanh.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dateNgayGhiDanh.Location = new System.Drawing.Point(111, 75);
            this.dateNgayGhiDanh.Name = "dateNgayGhiDanh";
            this.dateNgayGhiDanh.Size = new System.Drawing.Size(276, 25);
            this.dateNgayGhiDanh.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 15);
            this.label5.TabIndex = 18;
            this.label5.Text = "Ngày ghi danh:";
            // 
            // cboKhoaHoc
            // 
            this.cboKhoaHoc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboKhoaHoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhoaHoc.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboKhoaHoc.FormattingEnabled = true;
            this.cboKhoaHoc.Location = new System.Drawing.Point(111, 115);
            this.cboKhoaHoc.Name = "cboKhoaHoc";
            this.cboKhoaHoc.Size = new System.Drawing.Size(276, 25);
            this.cboKhoaHoc.TabIndex = 17;
            this.cboKhoaHoc.SelectedValueChanged += new System.EventHandler(this.cboKhoaHoc_SelectedValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Chọn khóa học:";
            // 
            // txtMaPhieu
            // 
            this.txtMaPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaPhieu.Enabled = false;
            this.txtMaPhieu.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtMaPhieu.Location = new System.Drawing.Point(111, 33);
            this.txtMaPhieu.Name = "txtMaPhieu";
            this.txtMaPhieu.Size = new System.Drawing.Size(276, 25);
            this.txtMaPhieu.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mã phiếu:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(785, 24);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(5, 474);
            this.panel5.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.gridPhieuGhiDanh);
            this.panel6.Controls.Add(this.lblTongCongPhieu);
            this.panel6.Controls.Add(this.label14);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(790, 24);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(276, 474);
            this.panel6.TabIndex = 6;
            // 
            // gridPhieuGhiDanh
            // 
            this.gridPhieuGhiDanh.AllowUserToAddRows = false;
            this.gridPhieuGhiDanh.AllowUserToResizeRows = false;
            this.gridPhieuGhiDanh.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridPhieuGhiDanh.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridPhieuGhiDanh.BackgroundColor = System.Drawing.Color.White;
            this.gridPhieuGhiDanh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gridPhieuGhiDanh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPhieuGhiDanh.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmMaPhieu,
            this.clmMaHV_DS,
            this.clmNgayGhiDanh,
            this.clmDaDong,
            this.clmConNo});
            this.gridPhieuGhiDanh.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gridPhieuGhiDanh.Location = new System.Drawing.Point(18, 38);
            this.gridPhieuGhiDanh.MultiSelect = false;
            this.gridPhieuGhiDanh.Name = "gridPhieuGhiDanh";
            this.gridPhieuGhiDanh.RowHeadersVisible = false;
            this.gridPhieuGhiDanh.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridPhieuGhiDanh.Size = new System.Drawing.Size(246, 409);
            this.gridPhieuGhiDanh.TabIndex = 5;
            this.gridPhieuGhiDanh.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.gridPhieuGhiDanh_RowsAdded);
            this.gridPhieuGhiDanh.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.gridPhieuGhiDanh_RowsRemoved);
            // 
            // clmMaPhieu
            // 
            this.clmMaPhieu.DataPropertyName = "MaPhieu";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Blue;
            this.clmMaPhieu.DefaultCellStyle = dataGridViewCellStyle2;
            this.clmMaPhieu.FillWeight = 80F;
            this.clmMaPhieu.HeaderText = "Mã phiếu";
            this.clmMaPhieu.Name = "clmMaPhieu";
            // 
            // clmMaHV_DS
            // 
            this.clmMaHV_DS.DataPropertyName = "MaHV";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.clmMaHV_DS.DefaultCellStyle = dataGridViewCellStyle3;
            this.clmMaHV_DS.HeaderText = "Mã học viên";
            this.clmMaHV_DS.Name = "clmMaHV_DS";
            // 
            // clmNgayGhiDanh
            // 
            this.clmNgayGhiDanh.DataPropertyName = "NgayGhiDanh";
            this.clmNgayGhiDanh.HeaderText = "Ngày ghi danh";
            this.clmNgayGhiDanh.Name = "clmNgayGhiDanh";
            // 
            // clmDaDong
            // 
            this.clmDaDong.DataPropertyName = "DaDong";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "C0";
            dataGridViewCellStyle4.NullValue = null;
            this.clmDaDong.DefaultCellStyle = dataGridViewCellStyle4;
            this.clmDaDong.HeaderText = "Đã đóng";
            this.clmDaDong.Name = "clmDaDong";
            // 
            // clmConNo
            // 
            this.clmConNo.DataPropertyName = "ConNo";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle5.Format = "C0";
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.clmConNo.DefaultCellStyle = dataGridViewCellStyle5;
            this.clmConNo.HeaderText = "Còn nợ";
            this.clmConNo.Name = "clmConNo";
            // 
            // lblTongCongPhieu
            // 
            this.lblTongCongPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTongCongPhieu.AutoSize = true;
            this.lblTongCongPhieu.Location = new System.Drawing.Point(15, 450);
            this.lblTongCongPhieu.Name = "lblTongCongPhieu";
            this.lblTongCongPhieu.Size = new System.Drawing.Size(195, 15);
            this.lblTongCongPhieu.TabIndex = 7;
            this.lblTongCongPhieu.Text = "Tổng cộng: <num> phiếu ghi danh";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(166, 15);
            this.label14.TabIndex = 6;
            this.label14.Text = "Danh sách các phiếu ghi danh";
            // 
            // frmLapPhieuGhiDanh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1066, 498);
            this.ControlBox = false;
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(48)))), ((int)(((byte)(70)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmLapPhieuGhiDanh";
            this.Text = "Lập phiếu ghi danh";
            this.Load += new System.EventHandler(this.frmLapPhieuGhiDanh_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDSHV)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numConNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaDong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHocPhi)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPhieuGhiDanh)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView gridDSHV;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmMaHV;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmTenHV;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmNgaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmGioiTinh;
        private System.Windows.Forms.Label lblTongCongHV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtMaPhieu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboKhoaHoc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numConNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numDaDong;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numHocPhi;
        private System.Windows.Forms.DateTimePicker dateNgayGhiDanh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDatLaiPhieu;
        private System.Windows.Forms.Button btnInBienLai;
        private System.Windows.Forms.Button btnLuuPhieu;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblTongCongPhieu;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView gridPhieuGhiDanh;
        private System.Windows.Forms.Button btnDatLai;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.TextBox txtTenHV;
        private System.Windows.Forms.TextBox txtMaHV;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnHienTatCa;
        private System.Windows.Forms.RadioButton rdTenHV;
        private System.Windows.Forms.RadioButton rdMaHV;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmMaPhieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmMaHV_DS;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmNgayGhiDanh;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDaDong;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmConNo;
    }
}